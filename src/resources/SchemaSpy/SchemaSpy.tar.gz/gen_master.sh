java -jar schemaSpy_5.0.0.jar -t pgsql -db DB_ESAFE_MASTER -host localhost -u postgres -p Orion@123 -o ./DB_ESAFE_MASTER -dp postgresql-9.4.1211.jre6.jar -s public -noads

